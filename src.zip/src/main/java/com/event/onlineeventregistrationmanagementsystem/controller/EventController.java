package com.event.onlineeventregistrationmanagementsystem.controller;

import com.event.onlineeventregistrationmanagementsystem.entity.Event;
import com.event.onlineeventregistrationmanagementsystem.repository.EventRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/events")
@CrossOrigin
public class EventController {

    private final EventRepository repo;

    public EventController(EventRepository repo) {
        this.repo = repo;
    }

    @PostMapping
    public Event addEvent(@RequestBody Event e) {
        return repo.save(e);
    }

    @GetMapping
    public List<Event> getAllEvents() {
        return repo.findAll();
    }

    @PutMapping("/{id}")
    public Event updateEvent(@PathVariable Long id, @RequestBody Event e) {
        e.setId(id);
        return repo.save(e);
    }

    @DeleteMapping("/{id}")
    public void deleteEvent(@PathVariable Long id) {
        repo.deleteById(id);
    }
}
